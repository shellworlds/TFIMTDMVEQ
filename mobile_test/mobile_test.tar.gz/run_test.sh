#!/bin/bash
echo "Starting mobile verification..."
python verify_light.py
echo ""
echo "For full verification:"
echo "1. Open https://github.com/shellworlds/TFIMTDMVEQ"
echo "2. Check data/tfim_ground_state.png"
echo "3. Review src/tfim_vqe.py"
